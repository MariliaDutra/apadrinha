# Apadrinha (React + Vite + Tailwind + Supabase)

Variáveis de ambiente (defina na Vercel):
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY

Build: `npm run build`
Output: `dist`
